<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="test1-1" tilewidth="100" tileheight="100" tilecount="96" columns="12">
 <image source="mapBackground1.2.png" width="1200" height="800"/>
</tileset>
