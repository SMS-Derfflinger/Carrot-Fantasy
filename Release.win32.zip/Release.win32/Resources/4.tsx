<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="4" tilewidth="100" tileheight="100" tilecount="104" columns="13">
 <image source="D:/Desktop/4.png" width="1300" height="800"/>
</tileset>
