<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="background" tilewidth="100" tileheight="100" tilecount="136" columns="17">
 <image source="background1.png" width="1778" height="800"/>
</tileset>
