<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="test04" tilewidth="93" tileheight="93" tilecount="96" columns="12">
 <image source="D:/Desktop/some other things/程序设计范式/Carrot-Fantasy/mapBackground1.1.png" width="1116" height="744"/>
</tileset>
