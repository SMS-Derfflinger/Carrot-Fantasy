<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="carrot" tilewidth="113" tileheight="113" tilecount="1" columns="1">
 <image source="rob6.png" width="113" height="113"/>
</tileset>
