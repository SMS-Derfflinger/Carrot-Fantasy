<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="addtower" tilewidth="72" tileheight="72" tilecount="1" columns="1">
 <image source="D:/Desktop/some other things/程序设计范式/Carrot-Fantasy/addTower.png" width="72" height="72"/>
</tileset>
